function redirectToAdmin() {
    window.location.href = "admin.html";
}

function redirectToStaff() {
    window.location.href = "staff.html";
}